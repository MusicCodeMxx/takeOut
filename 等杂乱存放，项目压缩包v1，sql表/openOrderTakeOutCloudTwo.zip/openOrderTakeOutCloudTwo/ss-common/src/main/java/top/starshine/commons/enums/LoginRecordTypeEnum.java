package top.starshine.commons.enums;

/**
 * <h3></h3>
 *
 * @author: starshine
 * @email: 183101655@qq.com
 * @version: 1.0
 * @since: 2022/7/27  下午 5:54  周三
 * @Description: hello world
 */
public enum LoginRecordTypeEnum {

    /**验证码登录*/
    VERIFICATION_CODE_LOGIN,

    /**退出登录*/
    LOGOUT

}
